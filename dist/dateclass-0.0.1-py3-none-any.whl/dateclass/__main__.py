from .commands import main

main()
